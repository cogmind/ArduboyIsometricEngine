#ifndef Playtune_h
#define Playtune_h
#include <Arduino.h>
class Playtune {
public:
void tune_initchan (byte pin);
void tune_playscore (const byte *score);
volatile static boolean tune_playing;
void tune_stopscore (void);
void tune_delay (unsigned msec);
void tune_stopchans (void); };
#endif