#include <Arduino.h>
#include "Playtune.h"
#ifndef DBUG
#define DBUG 0
#endif
#define ASSUME_VOLUME 0
#define TESLA_COIL 0
struct file_hdr_t {
char id1;     // 'P'
char id2;     // 't'
unsigned char hdr_length;
unsigned char f1;
unsigned char f2;
unsigned char num_tgens;
} file_header;
#define HDR_F1_VOLUME_PRESENT 0x80
#define HDR_F1_INSTRUMENTS_PRESENT 0x40
#define HDR_F1_PERCUSSION_PRESENT 0x20
#if defined(__AVR_ATmega8__)
#define TCCR2A TCCR2
#define TCCR2B TCCR2
#define COM2A1 COM21
#define COM2A0 COM20
#define OCR2A OCR2
#define TIMSK2 TIMSK
#define OCIE2A OCIE2
#define TIMER2_COMPA_vect TIMER2_COMP_vect
#define TIMSK1 TIMSK
#endif
#if !defined(__AVR_ATmega8__)
volatile byte *timer0_pin_port;
volatile byte timer0_pin_mask;
#endif
volatile byte *timer1_pin_port;
volatile byte timer1_pin_mask;
#if !defined(__AVR_ATmega32U4__)
volatile byte *timer2_pin_port;
volatile byte timer2_pin_mask;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
volatile byte *timer3_pin_port;
volatile byte timer3_pin_mask;
volatile byte *timer4_pin_port;
volatile byte timer4_pin_mask;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
volatile byte *timer5_pin_port;
volatile byte timer5_pin_mask;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
#define AVAILABLE_TIMERS 6
const byte PROGMEM tune_pin_to_timer_PGM[] = {
1, 2, 3, 4, 5, 0
};
#elif defined(__AVR_ATmega8__)
#define AVAILABLE_TIMERS 2
const byte PROGMEM tune_pin_to_timer_PGM[] = {
1, 2
};
#elif defined(__AVR_ATmega32U4__)
#define AVAILABLE_TIMERS 4
const byte PROGMEM tune_pin_to_timer_PGM[] = {
1, 0, 3, 4
};
#else
#define AVAILABLE_TIMERS 3
const byte PROGMEM tune_pin_to_timer_PGM[] = {
1, 2, 0
};
#endif
byte _tune_pins[AVAILABLE_TIMERS];
byte _tune_num_chans = 0;
volatile unsigned wait_timer_frequency2;
volatile unsigned wait_timer_old_frequency2;
volatile boolean wait_timer_playing = false;
volatile boolean doing_delay = false;
volatile unsigned long wait_toggle_count;
volatile unsigned long delay_toggle_count;
volatile const byte *score_start = 0;
volatile const byte *score_cursor = 0;
volatile boolean Playtune::tune_playing = false;
boolean volume_present = ASSUME_VOLUME;
const unsigned int PROGMEM tune_frequencies2_PGM[128] =
{
16, 17, 18, 19, 21, 22, 23, 24, 26, 28, 29, 31, 33, 35, 37, 39, 41,
44, 46, 49, 52, 55, 58, 62, 65, 69, 73, 78, 82, 87, 92, 98, 104, 110,
117, 123, 131, 139, 147, 156, 165, 175, 185, 196, 208, 220, 233,
247, 262, 277, 294, 311, 330, 349, 370, 392, 415, 440, 466, 494,
523, 554, 587, 622, 659, 698, 740, 784, 831, 880, 932, 988, 1047,
1109, 1175, 1245, 1319, 1397, 1480, 1568, 1661, 1760, 1865, 1976,
2093, 2217, 2349, 2489, 2637, 2794, 2960, 3136, 3322, 3520, 3729,
3951, 4186, 4435, 4699, 4978, 5274, 5588, 5920, 6272, 6645, 7040,
7459, 7902, 8372, 8870, 9397, 9956, 10548, 11175, 11840, 12544,
13290, 14080, 14917, 15804, 16744, 17740, 18795, 19912, 21096,
22351, 23680, 25088
};
void tune_playnote (byte chan, byte note);
void tune_stopnote (byte chan);
void tune_stepscore (void);
#if TESLA_COIL
void teslacoil_rising_edge(byte timernum);
byte teslacoil_checknote(byte note);
#endif
void Playtune::tune_initchan(byte pin) {
byte timer_num;
if (_tune_num_chans < AVAILABLE_TIMERS) {
timer_num = pgm_read_byte(tune_pin_to_timer_PGM + _tune_num_chans);
_tune_pins[_tune_num_chans] = pin;
_tune_num_chans++;
pinMode(pin, OUTPUT);
#if DBUG
Serial.print("init pin "); Serial.print(pin);
Serial.print(" on timer "); Serial.println(timer_num);
#endif
switch (timer_num) {
#if !defined(__AVR_ATmega8__)
case 0:
TCCR0A = 0;
TCCR0B = 0;
bitWrite(TCCR0A, WGM01, 1);
bitWrite(TCCR0B, CS00, 1);
timer0_pin_port = portOutputRegister(digitalPinToPort(pin));
timer0_pin_mask = digitalPinToBitMask(pin);
break;
#endif
case 1:
TCCR1A = 0;
TCCR1B = 0;
bitWrite(TCCR1B, WGM12, 1);
bitWrite(TCCR1B, CS10, 1);
timer1_pin_port = portOutputRegister(digitalPinToPort(pin));
timer1_pin_mask = digitalPinToBitMask(pin);
tune_playnote (0, 60);
tune_stopnote (0);
break;
#if !defined(__AVR_ATmega32U4__)
case 2:
TCCR2A = 0;
TCCR2B = 0;
bitWrite(TCCR2A, WGM21, 1);
bitWrite(TCCR2B, CS20, 1);
timer2_pin_port = portOutputRegister(digitalPinToPort(pin));
timer2_pin_mask = digitalPinToBitMask(pin);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
case 3:
TCCR3A = 0;
TCCR3B = 0;
bitWrite(TCCR3B, WGM32, 1);
bitWrite(TCCR3B, CS30, 1);
timer3_pin_port = portOutputRegister(digitalPinToPort(pin));
timer3_pin_mask = digitalPinToBitMask(pin);
break;
#endif
#if defined(__AVR_ATmega32U4__)
case 4:
TCCR4A = 0;
TCCR4B = 0;
bitWrite(TCCR4B, CS40, 1);
timer4_pin_port = portOutputRegister(digitalPinToPort(pin));
timer4_pin_mask = digitalPinToBitMask(pin);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
case 4:
TCCR4A = 0;
TCCR4B = 0;
bitWrite(TCCR4B, WGM42, 1);
bitWrite(TCCR4B, CS40, 1);
timer4_pin_port = portOutputRegister(digitalPinToPort(pin));
timer4_pin_mask = digitalPinToBitMask(pin);
break;
case 5:
TCCR5A = 0;
TCCR5B = 0;
bitWrite(TCCR5B, WGM52, 1);
bitWrite(TCCR5B, CS50, 1);
timer5_pin_port = portOutputRegister(digitalPinToPort(pin));
timer5_pin_mask = digitalPinToBitMask(pin);
break;
#endif
}
}
}
void tune_playnote (byte chan, byte note) {
byte timer_num;
byte prescalarbits = 0b001;
unsigned int frequency2;
unsigned long ocr;
#if DBUG
Serial.print ("Play at ");
Serial.print(score_cursor - score_start, HEX);
Serial.print(", ch");
Serial.print(chan); Serial.print(' ');
Serial.println(note, HEX);
#endif
if (chan < _tune_num_chans) {
timer_num = pgm_read_byte(tune_pin_to_timer_PGM + chan);
#if TESLA_COIL
note = teslacoil_checknote(note);
#endif
if (note > 127) note = 127;
frequency2 = pgm_read_word (tune_frequencies2_PGM + note);
if (timer_num == 0 || timer_num == 2
#if defined(__AVR_ATmega32U4__)
|| timer_num == 4
#endif
) {
if (note < ( F_CPU <= 8000000UL ? 12 : 24))
return;
ocr = F_CPU / frequency2 - 1;
prescalarbits = 0b001;
if (ocr > 255) {
ocr = F_CPU / frequency2 / 8 - 1;
prescalarbits = timer_num == 4 ? 0b0100 : 0b010;
if (timer_num == 2 && ocr > 255) {
ocr = F_CPU / frequency2 / 32 - 1;
prescalarbits = 0b011;
}
if (ocr > 255) {
ocr = F_CPU / frequency2 / 64 - 1;
prescalarbits = timer_num == 0 ? 0b011 : (timer_num == 4 ? 0b0111 : 0b100);
if (timer_num == 2 && ocr > 255) {
ocr = F_CPU / frequency2 / 128 - 1;
prescalarbits = 0b101;
}
if (ocr > 255) {
ocr = F_CPU / frequency2 / 256 - 1;
prescalarbits = timer_num == 0 ? 0b100 : (timer_num == 4 ? 0b1001 : 0b110);
if (ocr > 255) {
ocr = F_CPU / frequency2 / 1024 - 1;
prescalarbits = timer_num == 0 ? 0b101 : (timer_num == 4 ? 0b1011 : 0b111);
}
}
}
}
#if !defined(__AVR_ATmega8__)
if (timer_num == 0) TCCR0B = (TCCR0B & 0b11111000) | prescalarbits;
#if defined(__AVR_ATmega32U4__)
else if (timer_num == 4) {
TCCR4B = (TCCR4B & 0b11110000) | prescalarbits;
}
#endif
else {
#endif
#if !defined(__AVR_ATmega32U4__)
TCCR2B = (TCCR2B & 0b11111000) | prescalarbits;
#endif
}
}
else
{
ocr = F_CPU / frequency2 - 1;
prescalarbits = 0b001;
if (ocr > 0xffff) {
ocr = F_CPU / frequency2 / 64 - 1;
prescalarbits = 0b011;
}
if (timer_num == 1) TCCR1B = (TCCR1B & 0b11111000) | prescalarbits;
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
else if (timer_num == 3) TCCR3B = (TCCR3B & 0b11111000) | prescalarbits;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
else if (timer_num == 4) TCCR4B = (TCCR4B & 0b11111000) | prescalarbits;
else if (timer_num == 5) TCCR5B = (TCCR5B & 0b11111000) | prescalarbits;
#endif
}
switch (timer_num) {
#if !defined(__AVR_ATmega8__)
case 0:
OCR0A = ocr;
TCNT0 = 0;
bitWrite(TIMSK0, OCIE0A, 1);
break;
#endif
case 1:
OCR1A = ocr;
TCNT1 = 0;
wait_timer_frequency2 = frequency2;
wait_timer_playing = true;
bitWrite(TIMSK1, OCIE1A, 1);
break;
#if !defined(__AVR_ATmega32U4__)
case 2:
OCR2A = ocr;
TCNT2 = 0;
bitWrite(TIMSK2, OCIE2A, 1);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||(__AVR_ATmega32U4__)
case 3:
OCR3A = ocr;
TCNT3 = 0;
bitWrite(TIMSK3, OCIE3A, 1);
break;
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
case 4:
OCR4A = ocr;
TCNT4 = 0;
bitWrite(TIMSK4, OCIE4A, 1);
break;
#endif
#if defined(__AVR_ATmega32U4__)
case 4:
OCR4C = ocr / 2 + 1;
TCNT4 = 0;
bitWrite(TIMSK4, OCIE4A, 1);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
case 5:
OCR5A = ocr;
TCNT5 = 0;
bitWrite(TIMSK5, OCIE5A, 1);
break;
#endif
#endif
}
}
}
void tune_stopnote (byte chan) {
byte timer_num;
#if DBUG
Serial.print ("Stop note ");
Serial.println(chan, DEC);
#endif
timer_num = pgm_read_byte(tune_pin_to_timer_PGM + chan);
switch (timer_num) {
#if !defined(__AVR_ATmega8__)
case 0:
TIMSK0 &= ~(1 << OCIE0A);
*timer0_pin_port &= ~(timer0_pin_mask);
break;
#endif
case 1:
wait_timer_playing = false;
*timer1_pin_port &= ~(timer1_pin_mask);
break;
#if !defined(__AVR_ATmega32U4__)
case 2:
TIMSK2 &= ~(1 << OCIE1A);
*timer2_pin_port &= ~(timer2_pin_mask);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
case 3:
TIMSK3 &= ~(1 << OCIE3A);
*timer3_pin_port &= ~(timer3_pin_mask);
break;
case 4:
TIMSK4 &= ~(1 << OCIE4A);
*timer4_pin_port &= ~(timer4_pin_mask);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
case 5:
TIMSK5 &= ~(1 << OCIE5A);
*timer5_pin_port &= ~(timer5_pin_mask);
break;
#endif
}
}
void Playtune::tune_playscore (const byte *score) {
if (tune_playing) tune_stopscore();
score_start = score;
volume_present = ASSUME_VOLUME;
memcpy_P(&file_header, score, sizeof(file_hdr_t));
if (file_header.id1 == 'P' && file_header.id2 == 't') {
volume_present = file_header.f1 & HDR_F1_VOLUME_PRESENT;
#if DBUG
Serial.print("header: volume_present="); Serial.println(volume_present);
#endif
score_start += file_header.hdr_length;
}
score_cursor = score_start;
tune_stepscore();
Playtune::tune_playing = true;
}
void tune_stepscore (void) {
byte cmd, opcode, chan, note;
unsigned duration;
#define CMD_PLAYNOTE	0x90
#define CMD_STOPNOTE	0x80
#define CMD_INSTRUMENT  0xc0
#define CMD_RESTART	0xe0
#define CMD_STOP	0xf0
while (1) {
cmd = pgm_read_byte(score_cursor++);
if (cmd < 0x80) {
duration = ((unsigned)cmd << 8) | (pgm_read_byte(score_cursor++));
wait_toggle_count = ((unsigned long) wait_timer_frequency2 * duration + 500) / 1000;
if (wait_toggle_count == 0) wait_toggle_count = 1;
#if DBUG
Serial.print("wait "); Serial.print(duration);
Serial.print("ms, cnt ");
Serial.print(wait_toggle_count); Serial.print(" freq "); Serial.println(wait_timer_frequency2);
#endif
break;
}
opcode = cmd & 0xf0;
chan = cmd & 0x0f;
if (opcode == CMD_STOPNOTE) {
tune_stopnote (chan);
}
else if (opcode == CMD_PLAYNOTE) {
note = pgm_read_byte(score_cursor++);
if (volume_present) ++score_cursor;
tune_playnote (chan, note);
}
else if (opcode == CMD_INSTRUMENT) {
score_cursor++;
}
else if (opcode == CMD_RESTART) {
score_cursor = score_start;
}
else if (opcode == CMD_STOP) {
Playtune::tune_playing = false;
break;
}
}
}
void Playtune::tune_stopscore (void) {
int i;
for (i = 0; i < _tune_num_chans; ++i)
tune_stopnote(i);
Playtune::tune_playing = false;
}
void Playtune::tune_delay (unsigned duration) {
boolean notdone;
noInterrupts();
delay_toggle_count = ((unsigned long) wait_timer_frequency2 * duration + 500) / 1000;
doing_delay = true;
interrupts();
do {
noInterrupts();
notdone = delay_toggle_count != 0;
interrupts();
}
while (notdone);
doing_delay = false;
}
void Playtune::tune_stopchans(void) {
byte chan;
byte timer_num;
for (chan = 0; chan < _tune_num_chans; ++chan) {
timer_num = pgm_read_byte(tune_pin_to_timer_PGM + chan);
switch (timer_num) {
#if !defined(__AVR_ATmega8__)
case 0:
TIMSK0 &= ~(1 << OCIE0A);
break;
#endif
case 1:
TIMSK1 &= ~(1 << OCIE1A);
break;
#if !defined(__AVR_ATmega32U4__)
case 2:
TIMSK2 &= ~(1 << OCIE2A);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
case 3:
TIMSK3 &= ~(1 << OCIE3A);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
case 4:
TIMSK4 &= ~(1 << OCIE4A);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
case 5:
TIMSK5 &= ~(1 << OCIE5A);
break;
#endif
}
digitalWrite(_tune_pins[chan], 0);
}
_tune_num_chans = 0;
}
#if !defined(__AVR_ATmega8__) && !TESLA_COIL
ISR(TIMER0_COMPA_vect) {
*timer0_pin_port ^= timer0_pin_mask;
}
#endif
ISR(TIMER1_COMPA_vect) {
if (wait_timer_playing) {
*timer1_pin_port ^= timer1_pin_mask;
#if TESLA_COIL
if (*timer1_pin_port & timer1_pin_mask) teslacoil_rising_edge (2);
#endif
}
if (Playtune::tune_playing && wait_toggle_count && --wait_toggle_count == 0) {
wait_timer_old_frequency2 = wait_timer_frequency2;
tune_stepscore ();
if (doing_delay && wait_timer_old_frequency2 != wait_timer_frequency2) {
if (delay_toggle_count >= 0x20000UL && wait_timer_frequency2 >= 0x4000U) {
delay_toggle_count = ( (delay_toggle_count + 4 >> 3) * (wait_timer_frequency2 + 2 >> 2) / wait_timer_old_frequency2 ) << 5;
}
else {
delay_toggle_count = delay_toggle_count * wait_timer_frequency2 / wait_timer_old_frequency2;
}
}
}
if (doing_delay && delay_toggle_count) --delay_toggle_count;
}
#if !defined(__AVR_ATmega32U4__)
#if !TESLA_COIL
ISR(TIMER2_COMPA_vect) {
*timer2_pin_port ^= timer2_pin_mask;
}
#endif
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
ISR(TIMER3_COMPA_vect) {
*timer3_pin_port ^= timer3_pin_mask;
#if TESLA_COIL
if (*timer3_pin_port & timer3_pin_mask) teslacoil_rising_edge (3);
#endif
}
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
ISR(TIMER4_COMPA_vect) {
*timer4_pin_port ^= timer4_pin_mask;
#if TESLA_COIL
if (*timer4_pin_port & timer4_pin_mask) teslacoil_rising_edge (4);  // do a tesla coil pulse
#endif
}
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
ISR(TIMER5_COMPA_vect) {
*timer5_pin_port ^= timer5_pin_mask;
#if TESLA_COIL
if (*timer5_pin_port & timer5_pin_mask) teslacoil_rising_edge (5);
#endif
}
#endif#include <Arduino.h>
#include "Playtune.h"
#ifndef DBUG
#define DBUG 0
#endif
#define ASSUME_VOLUME 0
#define TESLA_COIL 0
struct file_hdr_t {
char id1;     // 'P'
char id2;     // 't'
unsigned char hdr_length;
unsigned char f1;
unsigned char f2;
unsigned char num_tgens;
} file_header;
#define HDR_F1_VOLUME_PRESENT 0x80
#define HDR_F1_INSTRUMENTS_PRESENT 0x40
#define HDR_F1_PERCUSSION_PRESENT 0x20
#if defined(__AVR_ATmega8__)
#define TCCR2A TCCR2
#define TCCR2B TCCR2
#define COM2A1 COM21
#define COM2A0 COM20
#define OCR2A OCR2
#define TIMSK2 TIMSK
#define OCIE2A OCIE2
#define TIMER2_COMPA_vect TIMER2_COMP_vect
#define TIMSK1 TIMSK
#endif
#if !defined(__AVR_ATmega8__)
volatile byte *timer0_pin_port;
volatile byte timer0_pin_mask;
#endif
volatile byte *timer1_pin_port;
volatile byte timer1_pin_mask;
#if !defined(__AVR_ATmega32U4__)
volatile byte *timer2_pin_port;
volatile byte timer2_pin_mask;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
volatile byte *timer3_pin_port;
volatile byte timer3_pin_mask;
volatile byte *timer4_pin_port;
volatile byte timer4_pin_mask;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
volatile byte *timer5_pin_port;
volatile byte timer5_pin_mask;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
#define AVAILABLE_TIMERS 6
const byte PROGMEM tune_pin_to_timer_PGM[] = {
1, 2, 3, 4, 5, 0
};
#elif defined(__AVR_ATmega8__)
#define AVAILABLE_TIMERS 2
const byte PROGMEM tune_pin_to_timer_PGM[] = {
1, 2
};
#elif defined(__AVR_ATmega32U4__)
#define AVAILABLE_TIMERS 4
const byte PROGMEM tune_pin_to_timer_PGM[] = {
1, 0, 3, 4
};
#else
#define AVAILABLE_TIMERS 3
const byte PROGMEM tune_pin_to_timer_PGM[] = {
1, 2, 0
};
#endif
byte _tune_pins[AVAILABLE_TIMERS];
byte _tune_num_chans = 0;
volatile unsigned wait_timer_frequency2;
volatile unsigned wait_timer_old_frequency2;
volatile boolean wait_timer_playing = false;
volatile boolean doing_delay = false;
volatile unsigned long wait_toggle_count;
volatile unsigned long delay_toggle_count;
volatile const byte *score_start = 0;
volatile const byte *score_cursor = 0;
volatile boolean Playtune::tune_playing = false;
boolean volume_present = ASSUME_VOLUME;
const unsigned int PROGMEM tune_frequencies2_PGM[128] =
{
16, 17, 18, 19, 21, 22, 23, 24, 26, 28, 29, 31, 33, 35, 37, 39, 41,
44, 46, 49, 52, 55, 58, 62, 65, 69, 73, 78, 82, 87, 92, 98, 104, 110,
117, 123, 131, 139, 147, 156, 165, 175, 185, 196, 208, 220, 233,
247, 262, 277, 294, 311, 330, 349, 370, 392, 415, 440, 466, 494,
523, 554, 587, 622, 659, 698, 740, 784, 831, 880, 932, 988, 1047,
1109, 1175, 1245, 1319, 1397, 1480, 1568, 1661, 1760, 1865, 1976,
2093, 2217, 2349, 2489, 2637, 2794, 2960, 3136, 3322, 3520, 3729,
3951, 4186, 4435, 4699, 4978, 5274, 5588, 5920, 6272, 6645, 7040,
7459, 7902, 8372, 8870, 9397, 9956, 10548, 11175, 11840, 12544,
13290, 14080, 14917, 15804, 16744, 17740, 18795, 19912, 21096,
22351, 23680, 25088
};
void tune_playnote (byte chan, byte note);
void tune_stopnote (byte chan);
void tune_stepscore (void);
#if TESLA_COIL
void teslacoil_rising_edge(byte timernum);
byte teslacoil_checknote(byte note);
#endif
void Playtune::tune_initchan(byte pin) {
byte timer_num;
if (_tune_num_chans < AVAILABLE_TIMERS) {
timer_num = pgm_read_byte(tune_pin_to_timer_PGM + _tune_num_chans);
_tune_pins[_tune_num_chans] = pin;
_tune_num_chans++;
pinMode(pin, OUTPUT);
#if DBUG
Serial.print("init pin "); Serial.print(pin);
Serial.print(" on timer "); Serial.println(timer_num);
#endif
switch (timer_num) {
#if !defined(__AVR_ATmega8__)
case 0:
TCCR0A = 0;
TCCR0B = 0;
bitWrite(TCCR0A, WGM01, 1);
bitWrite(TCCR0B, CS00, 1);
timer0_pin_port = portOutputRegister(digitalPinToPort(pin));
timer0_pin_mask = digitalPinToBitMask(pin);
break;
#endif
case 1:
TCCR1A = 0;
TCCR1B = 0;
bitWrite(TCCR1B, WGM12, 1);
bitWrite(TCCR1B, CS10, 1);
timer1_pin_port = portOutputRegister(digitalPinToPort(pin));
timer1_pin_mask = digitalPinToBitMask(pin);
tune_playnote (0, 60);
tune_stopnote (0);
break;
#if !defined(__AVR_ATmega32U4__)
case 2:
TCCR2A = 0;
TCCR2B = 0;
bitWrite(TCCR2A, WGM21, 1);
bitWrite(TCCR2B, CS20, 1);
timer2_pin_port = portOutputRegister(digitalPinToPort(pin));
timer2_pin_mask = digitalPinToBitMask(pin);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
case 3:
TCCR3A = 0;
TCCR3B = 0;
bitWrite(TCCR3B, WGM32, 1);
bitWrite(TCCR3B, CS30, 1);
timer3_pin_port = portOutputRegister(digitalPinToPort(pin));
timer3_pin_mask = digitalPinToBitMask(pin);
break;
#endif
#if defined(__AVR_ATmega32U4__)
case 4:
TCCR4A = 0;
TCCR4B = 0;
bitWrite(TCCR4B, CS40, 1);
timer4_pin_port = portOutputRegister(digitalPinToPort(pin));
timer4_pin_mask = digitalPinToBitMask(pin);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
case 4:
TCCR4A = 0;
TCCR4B = 0;
bitWrite(TCCR4B, WGM42, 1);
bitWrite(TCCR4B, CS40, 1);
timer4_pin_port = portOutputRegister(digitalPinToPort(pin));
timer4_pin_mask = digitalPinToBitMask(pin);
break;
case 5:
TCCR5A = 0;
TCCR5B = 0;
bitWrite(TCCR5B, WGM52, 1);
bitWrite(TCCR5B, CS50, 1);
timer5_pin_port = portOutputRegister(digitalPinToPort(pin));
timer5_pin_mask = digitalPinToBitMask(pin);
break;
#endif
}
}
}
void tune_playnote (byte chan, byte note) {
byte timer_num;
byte prescalarbits = 0b001;
unsigned int frequency2;
unsigned long ocr;
#if DBUG
Serial.print ("Play at ");
Serial.print(score_cursor - score_start, HEX);
Serial.print(", ch");
Serial.print(chan); Serial.print(' ');
Serial.println(note, HEX);
#endif
if (chan < _tune_num_chans) {
timer_num = pgm_read_byte(tune_pin_to_timer_PGM + chan);
#if TESLA_COIL
note = teslacoil_checknote(note);
#endif
if (note > 127) note = 127;
frequency2 = pgm_read_word (tune_frequencies2_PGM + note);
if (timer_num == 0 || timer_num == 2
#if defined(__AVR_ATmega32U4__)
|| timer_num == 4
#endif
) {
if (note < ( F_CPU <= 8000000UL ? 12 : 24))
return;
ocr = F_CPU / frequency2 - 1;
prescalarbits = 0b001;
if (ocr > 255) {
ocr = F_CPU / frequency2 / 8 - 1;
prescalarbits = timer_num == 4 ? 0b0100 : 0b010;
if (timer_num == 2 && ocr > 255) {
ocr = F_CPU / frequency2 / 32 - 1;
prescalarbits = 0b011;
}
if (ocr > 255) {
ocr = F_CPU / frequency2 / 64 - 1;
prescalarbits = timer_num == 0 ? 0b011 : (timer_num == 4 ? 0b0111 : 0b100);
if (timer_num == 2 && ocr > 255) {
ocr = F_CPU / frequency2 / 128 - 1;
prescalarbits = 0b101;
}
if (ocr > 255) {
ocr = F_CPU / frequency2 / 256 - 1;
prescalarbits = timer_num == 0 ? 0b100 : (timer_num == 4 ? 0b1001 : 0b110);
if (ocr > 255) {
ocr = F_CPU / frequency2 / 1024 - 1;
prescalarbits = timer_num == 0 ? 0b101 : (timer_num == 4 ? 0b1011 : 0b111);
}
}
}
}
#if !defined(__AVR_ATmega8__)
if (timer_num == 0) TCCR0B = (TCCR0B & 0b11111000) | prescalarbits;
#if defined(__AVR_ATmega32U4__)
else if (timer_num == 4) {
TCCR4B = (TCCR4B & 0b11110000) | prescalarbits;
}
#endif
else {
#endif
#if !defined(__AVR_ATmega32U4__)
TCCR2B = (TCCR2B & 0b11111000) | prescalarbits;
#endif
}
}
else
{
ocr = F_CPU / frequency2 - 1;
prescalarbits = 0b001;
if (ocr > 0xffff) {
ocr = F_CPU / frequency2 / 64 - 1;
prescalarbits = 0b011;
}
if (timer_num == 1) TCCR1B = (TCCR1B & 0b11111000) | prescalarbits;
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
else if (timer_num == 3) TCCR3B = (TCCR3B & 0b11111000) | prescalarbits;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
else if (timer_num == 4) TCCR4B = (TCCR4B & 0b11111000) | prescalarbits;
else if (timer_num == 5) TCCR5B = (TCCR5B & 0b11111000) | prescalarbits;
#endif
}
switch (timer_num) {
#if !defined(__AVR_ATmega8__)
case 0:
OCR0A = ocr;
TCNT0 = 0;
bitWrite(TIMSK0, OCIE0A, 1);
break;
#endif
case 1:
OCR1A = ocr;
TCNT1 = 0;
wait_timer_frequency2 = frequency2;
wait_timer_playing = true;
bitWrite(TIMSK1, OCIE1A, 1);
break;
#if !defined(__AVR_ATmega32U4__)
case 2:
OCR2A = ocr;
TCNT2 = 0;
bitWrite(TIMSK2, OCIE2A, 1);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||(__AVR_ATmega32U4__)
case 3:
OCR3A = ocr;
TCNT3 = 0;
bitWrite(TIMSK3, OCIE3A, 1);
break;
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
case 4:
OCR4A = ocr;
TCNT4 = 0;
bitWrite(TIMSK4, OCIE4A, 1);
break;
#endif
#if defined(__AVR_ATmega32U4__)
case 4:
OCR4C = ocr / 2 + 1;
TCNT4 = 0;
bitWrite(TIMSK4, OCIE4A, 1);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
case 5:
OCR5A = ocr;
TCNT5 = 0;
bitWrite(TIMSK5, OCIE5A, 1);
break;
#endif
#endif
}
}
}
void tune_stopnote (byte chan) {
byte timer_num;
#if DBUG
Serial.print ("Stop note ");
Serial.println(chan, DEC);
#endif
timer_num = pgm_read_byte(tune_pin_to_timer_PGM + chan);
switch (timer_num) {
#if !defined(__AVR_ATmega8__)
case 0:
TIMSK0 &= ~(1 << OCIE0A);
*timer0_pin_port &= ~(timer0_pin_mask);
break;
#endif
case 1:
wait_timer_playing = false;
*timer1_pin_port &= ~(timer1_pin_mask);
break;
#if !defined(__AVR_ATmega32U4__)
case 2:
TIMSK2 &= ~(1 << OCIE1A);
*timer2_pin_port &= ~(timer2_pin_mask);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
case 3:
TIMSK3 &= ~(1 << OCIE3A);
*timer3_pin_port &= ~(timer3_pin_mask);
break;
case 4:
TIMSK4 &= ~(1 << OCIE4A);
*timer4_pin_port &= ~(timer4_pin_mask);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
case 5:
TIMSK5 &= ~(1 << OCIE5A);
*timer5_pin_port &= ~(timer5_pin_mask);
break;
#endif
}
}
void Playtune::tune_playscore (const byte *score) {
if (tune_playing) tune_stopscore();
score_start = score;
volume_present = ASSUME_VOLUME;
memcpy_P(&file_header, score, sizeof(file_hdr_t));
if (file_header.id1 == 'P' && file_header.id2 == 't') {
volume_present = file_header.f1 & HDR_F1_VOLUME_PRESENT;
#if DBUG
Serial.print("header: volume_present="); Serial.println(volume_present);
#endif
score_start += file_header.hdr_length;
}
score_cursor = score_start;
tune_stepscore();
Playtune::tune_playing = true;
}
void tune_stepscore (void) {
byte cmd, opcode, chan, note;
unsigned duration;
#define CMD_PLAYNOTE	0x90
#define CMD_STOPNOTE	0x80
#define CMD_INSTRUMENT  0xc0
#define CMD_RESTART	0xe0
#define CMD_STOP	0xf0
while (1) {
cmd = pgm_read_byte(score_cursor++);
if (cmd < 0x80) {
duration = ((unsigned)cmd << 8) | (pgm_read_byte(score_cursor++));
wait_toggle_count = ((unsigned long) wait_timer_frequency2 * duration + 500) / 1000;
if (wait_toggle_count == 0) wait_toggle_count = 1;
#if DBUG
Serial.print("wait "); Serial.print(duration);
Serial.print("ms, cnt ");
Serial.print(wait_toggle_count); Serial.print(" freq "); Serial.println(wait_timer_frequency2);
#endif
break;
}
opcode = cmd & 0xf0;
chan = cmd & 0x0f;
if (opcode == CMD_STOPNOTE) {
tune_stopnote (chan);
}
else if (opcode == CMD_PLAYNOTE) {
note = pgm_read_byte(score_cursor++);
if (volume_present) ++score_cursor;
tune_playnote (chan, note);
}
else if (opcode == CMD_INSTRUMENT) {
score_cursor++;
}
else if (opcode == CMD_RESTART) {
score_cursor = score_start;
}
else if (opcode == CMD_STOP) {
Playtune::tune_playing = false;
break;
}
}
}
void Playtune::tune_stopscore (void) {
int i;
for (i = 0; i < _tune_num_chans; ++i)
tune_stopnote(i);
Playtune::tune_playing = false;
}
void Playtune::tune_delay (unsigned duration) {
boolean notdone;
noInterrupts();
delay_toggle_count = ((unsigned long) wait_timer_frequency2 * duration + 500) / 1000;
doing_delay = true;
interrupts();
do {
noInterrupts();
notdone = delay_toggle_count != 0;
interrupts();
}
while (notdone);
doing_delay = false;
}
void Playtune::tune_stopchans(void) {
byte chan;
byte timer_num;
for (chan = 0; chan < _tune_num_chans; ++chan) {
timer_num = pgm_read_byte(tune_pin_to_timer_PGM + chan);
switch (timer_num) {
#if !defined(__AVR_ATmega8__)
case 0:
TIMSK0 &= ~(1 << OCIE0A);
break;
#endif
case 1:
TIMSK1 &= ~(1 << OCIE1A);
break;
#if !defined(__AVR_ATmega32U4__)
case 2:
TIMSK2 &= ~(1 << OCIE2A);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
case 3:
TIMSK3 &= ~(1 << OCIE3A);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
case 4:
TIMSK4 &= ~(1 << OCIE4A);
break;
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
case 5:
TIMSK5 &= ~(1 << OCIE5A);
break;
#endif
}
digitalWrite(_tune_pins[chan], 0);
}
_tune_num_chans = 0;
}
#if !defined(__AVR_ATmega8__) && !TESLA_COIL
ISR(TIMER0_COMPA_vect) {
*timer0_pin_port ^= timer0_pin_mask;
}
#endif
ISR(TIMER1_COMPA_vect) {
if (wait_timer_playing) {
*timer1_pin_port ^= timer1_pin_mask;
#if TESLA_COIL
if (*timer1_pin_port & timer1_pin_mask) teslacoil_rising_edge (2);
#endif
}
if (Playtune::tune_playing && wait_toggle_count && --wait_toggle_count == 0) {
wait_timer_old_frequency2 = wait_timer_frequency2;
tune_stepscore ();
if (doing_delay && wait_timer_old_frequency2 != wait_timer_frequency2) {
if (delay_toggle_count >= 0x20000UL && wait_timer_frequency2 >= 0x4000U) {
delay_toggle_count = ( (delay_toggle_count + 4 >> 3) * (wait_timer_frequency2 + 2 >> 2) / wait_timer_old_frequency2 ) << 5;
}
else {
delay_toggle_count = delay_toggle_count * wait_timer_frequency2 / wait_timer_old_frequency2;
}
}
}
if (doing_delay && delay_toggle_count) --delay_toggle_count;
}
#if !defined(__AVR_ATmega32U4__)
#if !TESLA_COIL
ISR(TIMER2_COMPA_vect) {
*timer2_pin_port ^= timer2_pin_mask;
}
#endif
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
ISR(TIMER3_COMPA_vect) {
*timer3_pin_port ^= timer3_pin_mask;
#if TESLA_COIL
if (*timer3_pin_port & timer3_pin_mask) teslacoil_rising_edge (3);
#endif
}
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)||defined(__AVR_ATmega32U4__)
ISR(TIMER4_COMPA_vect) {
*timer4_pin_port ^= timer4_pin_mask;
#if TESLA_COIL
if (*timer4_pin_port & timer4_pin_mask) teslacoil_rising_edge (4);  // do a tesla coil pulse
#endif
}
#endif
#if defined(__AVR_ATmega1280__)||defined(__AVR_ATmega2560__)
ISR(TIMER5_COMPA_vect) {
*timer5_pin_port ^= timer5_pin_mask;
#if TESLA_COIL
if (*timer5_pin_port & timer5_pin_mask) teslacoil_rising_edge (5);
#endif
}
#endif